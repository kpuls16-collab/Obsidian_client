# Requested project specification

Create a production-oriented, modular Fabric utility client for Minecraft 26.1.2 using Java 25, Fabric Loom 1.15 and unobfuscated Mojang mappings.

Requested deliverables:
- `.github/workflows/build.yml` using Java 25 Temurin/Adoptium, Gradle caching, `./gradlew build`, and upload of the built JAR on pushes and pull requests.
- Gradle build configuration, `gradle.properties`, `fabric.mod.json`, and Mixin JSON.
- Implemented EventBus, RotationManager, ClickGUI, AutoCrystal, AutoTotem, AutoAnchor, SafeAnchor and BaseFinder.
- Gradle `zipClient` ZIP task packaging the source workspace.
- Include complete source files, not placeholder summaries.

This archive contains the source workspace and this specification. It does not contain a compiled JAR because no build has yet been run successfully against the target game/toolchain.
