# Fabric Utility Client

A modular Fabric client-side utility mod workspace targeting the requested Minecraft **26.1.2**, Java **25**, Fabric Loom **1.15** configuration.

## Included
- Gradle project configuration and Fabric metadata
- GitHub Actions build workflow (`.github/workflows/build.yml`)
- Mixin configuration and client entrypoint
- Event bus, rotation manager, ClickGUI screen
- AutoCrystal, AutoTotem, AutoAnchor, SafeAnchor and BaseFinder module implementations
- `zipClient` Gradle task to package the project source
- Original request/specification in `PROJECT_SPEC.md`

## Build
Requires JDK 25 and a Gradle installation (or a Gradle wrapper generated for the installed Gradle distribution).

```bash
gradle wrapper
./gradlew build
```

The CI workflow runs the wrapper build and uploads the resulting JAR from `build/libs/`.

## Compatibility note
Minecraft 26.1.2 and Fabric Loom 1.15 are the requested target values. Fabric Loader, Fabric API, mappings and Minecraft client APIs evolve independently; verify the matching published versions before treating this workspace as a release build. This archive is source code, not a prebuilt or verified JAR. The first CI run is the definitive compatibility check.

## Controls
- Right Shift: open the ClickGUI
- Modules are toggled from the GUI
- Module settings are intentionally conservative; combat automation is disabled by default

## Project layout
- `src/main/java/.../event`: event bus and events
- `src/main/java/.../manager`: rotation manager
- `src/main/java/.../module`: module framework and requested modules
- `src/main/java/.../gui`: ClickGUI
- `src/main/java/.../mixin`: client tick and input hooks
