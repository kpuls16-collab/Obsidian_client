package dev.example.utility.module.impl;

import dev.example.utility.module.Category;
import dev.example.utility.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Items;

/** Moves a totem into the offhand when available and the offhand is empty. */
public final class AutoTotemModule extends Module {
    public AutoTotemModule() {
        super("AutoTotem", "Keeps a totem in the offhand when possible", Category.PLAYER);
    }

    @Override protected void onTick(Minecraft client) {
        if (client.player == null || client.gameMode == null) return;
        if (!client.player.getOffhandItem().isEmpty()) return;
        Inventory inventory = client.player.getInventory();
        int totemSlot = -1;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            if (inventory.getItem(i).is(Items.TOTEM_OF_UNDYING)) {
                totemSlot = i;
                break;
            }
        }
        if (totemSlot >= 0) {
            // Swap selected inventory slot with offhand using the standard
            // inventory click protocol. Slot 40 is the offhand slot.
            client.gameMode.handleInventoryMouseClick(
                    client.player.containerMenu.containerId,
                    totemSlot < 9 ? totemSlot + 36 : totemSlot,
                    40,
                    net.minecraft.world.inventory.ClickType.SWAP,
                    client.player
            );
        }
    }
}
