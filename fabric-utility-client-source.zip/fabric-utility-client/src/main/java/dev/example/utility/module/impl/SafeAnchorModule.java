package dev.example.utility.module.impl;

import dev.example.utility.module.Category;
import dev.example.utility.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.world.item.Items;

/** Prevents accidental anchor charging outside the Nether. */
public final class SafeAnchorModule extends Module {
    public SafeAnchorModule() {
        super("SafeAnchor", "Safety guard for respawn anchors", Category.PLAYER);
    }

    @Override protected void onTick(Minecraft client) {
        if (client.player == null || client.level == null || client.gameMode == null) return;
        // The mixin input hook can consult this module before right-click
        // dispatch. No input is synthesized by this guard.
    }

    public boolean shouldBlockAnchorUse(Minecraft client) {
        return client.level != null && !client.level.dimensionType().respawnAnchorWorks();
    }
}
