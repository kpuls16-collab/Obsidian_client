package dev.example.utility.module.impl;

import dev.example.utility.module.Category;
import dev.example.utility.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import java.util.Optional;

/**
 * Local base scanner. Searches a bounded cube around the player for common
 * player-built storage/utility blocks and exposes the nearest match.
 */
public final class BaseFinderModule extends Module {
    private static final int RADIUS = 24;
    private BlockPos nearest;

    public BaseFinderModule() {
        super("BaseFinder", "Scans nearby chunks for common base indicators", Category.WORLD);
    }

    @Override protected void onTick(Minecraft client) {
        if (client.player == null || client.level == null) return;
        BlockPos origin = client.player.blockPosition();
        BlockPos best = null;
        double bestDistance = Double.MAX_VALUE;
        for (BlockPos pos : BlockPos.betweenClosed(
                origin.offset(-RADIUS, -8, -RADIUS),
                origin.offset(RADIUS, 8, RADIUS))) {
            var state = client.level.getBlockState(pos);
            if (state.is(Blocks.CHEST) || state.is(Blocks.TRAPPED_CHEST)
                    || state.is(Blocks.BARREL) || state.is(Blocks.ENDER_CHEST)
                    || state.is(Blocks.FURNACE) || state.is(Blocks.BLAST_FURNACE)) {
                double distance = pos.distSqr(origin);
                if (distance < bestDistance) {
                    bestDistance = distance;
                    best = pos.immutable();
                }
            }
        }
        nearest = best;
    }

    public Optional<BlockPos> nearestIndicator() { return Optional.ofNullable(nearest); }
}
