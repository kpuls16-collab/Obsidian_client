package dev.example.utility.event;

import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

/**
 * Small synchronous event bus. Listener order is registration order; listeners
 * should remain fast because events are posted on the client thread.
 */
public final class EventBus {
    private final Map<Class<?>, CopyOnWriteArrayList<Consumer<Object>>> listeners = new ConcurrentHashMap<>();
    private final Map<Object, List<Subscription>> subscriptions = new IdentityHashMap<>();

    public <T> Subscription subscribe(Class<T> eventType, Consumer<T> listener) {
        Objects.requireNonNull(eventType);
        Objects.requireNonNull(listener);
        Consumer<Object> bridge = event -> listener.accept(eventType.cast(event));
        listeners.computeIfAbsent(eventType, ignored -> new CopyOnWriteArrayList<>()).add(bridge);
        Subscription subscription = new Subscription(() -> listeners.getOrDefault(eventType, new CopyOnWriteArrayList<>()).remove(bridge));
        return subscription;
    }

    public void register(Object listener) {
        Objects.requireNonNull(listener);
        List<Subscription> owned = new ArrayList<>();
        for (Method method : listener.getClass().getDeclaredMethods()) {
            Subscribe annotation = method.getAnnotation(Subscribe.class);
            if (annotation == null || method.getParameterCount() != 1) continue;
            method.setAccessible(true);
            Class<?> eventType = method.getParameterTypes()[0];
            owned.add(subscribeUnchecked(eventType, event -> {
                try {
                    method.invoke(listener, event);
                } catch (ReflectiveOperationException exception) {
                    throw new EventDispatchException(method, exception);
                }
            }));
        }
        synchronized (subscriptions) {
            subscriptions.put(listener, owned);
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private Subscription subscribeUnchecked(Class<?> type, Consumer<Object> consumer) {
        return subscribe((Class) type, (Consumer) consumer);
    }

    public void unregister(Object listener) {
        List<Subscription> owned;
        synchronized (subscriptions) {
            owned = subscriptions.remove(listener);
        }
        if (owned != null) owned.forEach(Subscription::close);
    }

    public void post(Object event) {
        Objects.requireNonNull(event);
        Class<?> type = event.getClass();
        listeners.forEach((registeredType, consumers) -> {
            if (registeredType.isAssignableFrom(type)) {
                for (Consumer<Object> consumer : consumers) consumer.accept(event);
            }
        });
    }

    public static final class Subscription implements AutoCloseable {
        private final Runnable remover;
        private boolean closed;
        private Subscription(Runnable remover) { this.remover = remover; }
        @Override public synchronized void close() {
            if (!closed) { closed = true; remover.run(); }
        }
    }

    public static final class EventDispatchException extends RuntimeException {
        public EventDispatchException(Method method, Throwable cause) {
            super("Failed to dispatch event to " + method, cause);
        }
    }
}
