package dev.example.utility.manager;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec2;

/**
 * Centralized, priority-based rotation requests. Modules request a target;
 * the manager applies the winning request once per tick and can be reset.
 */
public final class RotationManager {
    private static final RotationManager INSTANCE = new RotationManager();
    private Request request;

    public static RotationManager get() { return INSTANCE; }

    public synchronized void request(float yaw, float pitch, int priority, String owner) {
        if (owner == null || owner.isBlank()) throw new IllegalArgumentException("owner is required");
        float clampedPitch = Math.max(-90.0f, Math.min(90.0f, pitch));
        if (request == null || priority >= request.priority()) {
            request = new Request(yaw, clampedPitch, priority, owner);
        }
    }

    public synchronized void apply(Minecraft client) {
        if (request == null) return;
        Player player = client.player;
        if (player != null) {
            player.setYRot(request.yaw());
            player.setXRot(request.pitch());
        }
        request = null;
    }

    public synchronized void clear() { request = null; }
    public synchronized String currentOwner() { return request == null ? null : request.owner(); }

    private record Request(float yaw, float pitch, int priority, String owner) {}
}
