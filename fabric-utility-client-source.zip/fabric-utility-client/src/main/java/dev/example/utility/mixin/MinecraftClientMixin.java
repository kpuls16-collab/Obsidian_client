package dev.example.utility.mixin;

import dev.example.utility.manager.RotationManager;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public abstract class MinecraftClientMixin {
    @Inject(method = "tick", at = @At("TAIL"))
    private void fabricUtilityClient$applyRotations(CallbackInfo ci) {
        RotationManager.get().apply((Minecraft) (Object) this);
    }
}
