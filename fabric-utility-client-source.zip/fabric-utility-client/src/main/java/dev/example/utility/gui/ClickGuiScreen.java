package dev.example.utility.gui;

import dev.example.utility.FabricUtilityClient;
import dev.example.utility.module.Module;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Minimal keyboard/mouse-accessible module list screen. */
public final class ClickGuiScreen extends Screen {
    private static final int LEFT = 24;
    private static final int TOP = 32;
    private static final int ROW_HEIGHT = 22;

    public ClickGuiScreen() {
        super(Component.literal("Fabric Utility Client"));
    }

    @Override public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        renderBackground(graphics, mouseX, mouseY, delta);
        graphics.drawCenteredString(font, title, width / 2, 12, 0xFFFFFF);
        int y = TOP;
        for (Module module : FabricUtilityClient.MODULES.all()) {
            int color = module.isEnabled() ? 0xFF55FF55 : 0xFFFFFFFF;
            graphics.fill(LEFT, y, LEFT + 220, y + ROW_HEIGHT - 2, 0xAA202020);
            graphics.drawString(font, module.name(), LEFT + 8, y + 6, color);
            graphics.drawString(font, module.category().name(), LEFT + 150, y + 6, 0xFFAAAAAA);
            y += ROW_HEIGHT;
        }
        graphics.drawString(font, "Click a module to toggle it. ESC to close.", LEFT, y + 8, 0xFFCCCCCC);
        super.render(graphics, mouseX, mouseY, delta);
    }

    @Override public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && mouseX >= LEFT && mouseX <= LEFT + 220 && mouseY >= TOP) {
            int index = ((int) mouseY - TOP) / ROW_HEIGHT;
            var modules = FabricUtilityClient.MODULES.all();
            if (index >= 0 && index < modules.size()) modules.get(index).toggle();
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override public boolean isPauseScreen() { return false; }
}
