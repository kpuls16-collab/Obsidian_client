package dev.example.utility.event.events;

import net.minecraft.client.Minecraft;

public record ClientTickEvent(Minecraft client) {}
