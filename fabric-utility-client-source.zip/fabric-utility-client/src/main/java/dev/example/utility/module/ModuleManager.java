package dev.example.utility.module;

import dev.example.utility.module.impl.*;
import net.minecraft.client.Minecraft;
import java.util.*;

public final class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public void register(Module module) {
        if (modules.stream().anyMatch(existing -> existing.name().equalsIgnoreCase(module.name()))) {
            throw new IllegalArgumentException("Duplicate module: " + module.name());
        }
        modules.add(module);
    }

    public void registerDefaults() {
        register(new AutoCrystalModule());
        register(new AutoTotemModule());
        register(new AutoAnchorModule());
        register(new SafeAnchorModule());
        register(new BaseFinderModule());
    }

    public void tick(Minecraft client) {
        for (Module module : List.copyOf(modules)) module.tick(client);
    }

    public List<Module> all() { return Collections.unmodifiableList(modules); }
}
