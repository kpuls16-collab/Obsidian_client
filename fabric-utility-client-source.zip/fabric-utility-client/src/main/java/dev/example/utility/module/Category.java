package dev.example.utility.module;

public enum Category {
    COMBAT, PLAYER, WORLD, RENDER, MISC
}
