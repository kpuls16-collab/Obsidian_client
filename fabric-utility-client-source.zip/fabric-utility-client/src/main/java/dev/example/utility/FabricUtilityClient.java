package dev.example.utility;

import dev.example.utility.event.EventBus;
import dev.example.utility.event.events.ClientTickEvent;
import dev.example.utility.gui.ClickGuiScreen;
import dev.example.utility.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public final class FabricUtilityClient implements ClientModInitializer {
    public static final String MOD_ID = "fabric_utility_client";
    public static final EventBus EVENTS = new EventBus();
    public static final ModuleManager MODULES = new ModuleManager();
    private static KeyMapping clickGuiKey;

    @Override
    public void onInitializeClient() {
        MODULES.registerDefaults();
        clickGuiKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.fabric_utility_client.click_gui",
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyMapping.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            EVENTS.post(new ClientTickEvent(client));
            while (clickGuiKey.consumeClick()) {
                if (client.screen == null) {
                    client.setScreen(new ClickGuiScreen());
                } else if (client.screen instanceof ClickGuiScreen) {
                    client.setScreen(null);
                }
            }
            MODULES.tick(client);
        });
    }
}
